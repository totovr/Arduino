# GridEye
An Arduino library for the Grid-EYE Infrared Array Sensors
